
<div class=" uk-container-expand staticimage uk-margin-medium-top uk-margin-medium-bottom bgcolor-wrapper">
	<div id="banner">
		<div class=" inner">
            <h5 class="banner-title uk-text-center">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nulla molestiae, voluptas iure! Iusto voluptatum qui placeat vo  </h5>          
		</div>
	</div>
</div>
