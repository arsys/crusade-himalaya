<section class="uk-container-expand category" uk-grid>
	<div class="uk-height-large  uk-width-*@s  uk-background-cover uk-light category-cover" data-src="https://source.unsplash.com/1200x800/?bird" uk-img>
		<h1 class="page-heading uk-margin-large-left">Category</h1>
		<h3 class="page-subheading uk-margin-large-left uk-margin-top uk-margin-bottom">Lorem ipsum dolor sit amet.</h3>
		<div class="cat-breadcrumb ">
			<ul class="uk-breadcrumb" id="cat-breadcrumb">
				<li><a href="#">list</a></li>
				<li><a href="#">list</a></li>
				<li class="uk-disabled"><a>Disabled</a></li>
				<li><span>Active</span></li>
			</ul>
		</div>
	</div>
</section>
