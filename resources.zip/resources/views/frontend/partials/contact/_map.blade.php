	<div class="map-wrapper uk-section-default">
	    <div id="map" style="height: 300px;"></div>
	</div>
