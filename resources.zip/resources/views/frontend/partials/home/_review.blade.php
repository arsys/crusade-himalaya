<!-- 
<div class="uk-container uk-margin-medium-top uk-margin-mediumm-bottom">
    <div class="uk-grid-divider " uk-grid >
        <div class="uk-width-1-2@m">
            <h2 class=" uk-text-center  uk-text-center uk-margin-mediumm-bottom"><span>Company CSR</span></h2>
            <p >Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>
        </div>
        <div class="uk-width-1-2@m tripadvisor">
            <div id="TA_selfserveprop300" class="TA_selfserveprop"  >
                <ul id="9ZD65F" class="TA_links 0pXbkxRG" >
                    <li id="f9EWdyMnqr8D" class="gHqyfD">
                        <a target="_blank"  href="https://www.tripadvisor.com/"><img  src="https://www.tripadvisor.com/img/cdsi/img2/branding/150_logo-11900-2.png" alt="TripAdvisor"/></a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<script async src="https://www.jscache.com/wejs?wtype=selfserveprop&amp;uniq=300&amp;locationId=12676572&amp;lang=en_US&amp;rating=true&amp;nreviews=4&amp;writereviewlink=true&amp;popIdx=true&amp;iswide=true&amp;border=true&amp;display_version=2" data-loadtrk onload="this.loadtrk=true"></script> -->