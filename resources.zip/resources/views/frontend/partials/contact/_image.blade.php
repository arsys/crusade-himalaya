<section class="uk-container-expand">
	<div class="uk-height-large uk-flex uk-flex-center uk-flex-middle uk-background-cover uk-light" data-src="https://source.unsplash.com/1200x800/?arts" uk-img>
	<div class="uk-overlay-primary uk-position-cover overlay"></div>
	<h1 class="main-heading">Contact us</h1>
		<div class="contact-breadcrumb ">
			<ul class="uk-breadcrumb  " id="contact-breadcrumb">
				<li><a href="/" uk-icon="icon: home" ></a></li>
				<li class="uk-disabled"><a href="{{ url()->current() }}">Contact Us</a></li>
			</ul>
		</div>	
	</div>
</section>