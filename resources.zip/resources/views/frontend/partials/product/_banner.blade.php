<section class=" uk-container-expand product-cover">
	<div class="uk-height-large uk-flex  uk-background-cover uk-light" data-src="https://source.unsplash.com/1200x800/?bird" uk-img>
 	 	<h3 class="uk-text-center uk-margin-auto uk-margin-auto-vertical">Background-image</h3>
		<div class="breadcrumb uk-visible@l ">
			<ul class="uk-breadcrumb" id="breadcrumb">
				<li><a href="#">Item</a></li>
				<li><a href="#">Item</a></li>
				<li class="uk-disabled"><a>Disabled</a></li>
				<li><span>Active</span></li>
			</ul>
		</div>		
	</div>	
</section>