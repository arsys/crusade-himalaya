@extends('layouts.backend')
@section('styles')
    <link type="text/css" rel="stylesheet" href="{{ asset('assets/backend/css/libs/dropzone/dropzone-theme.css') }}" />
@stop
@section('content')
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="card">
                <div class="card-head style-primary">
                    <header>Drag and drop uploader</header>
                </div>
                <div class="card-body no-padding">
                    <form
                            method="POST"
                            action="{{route('carousel.store')}}"
                            class="dropzone"
                            id="addPhotosForm">
                        {{ csrf_field() }}
                        <div class="dz-message">
                            <h3>Drop files here or click to upload.</h3>
                            <h4>Resolution: 1200x630</h4>
                        </div>
                    </form>
                </div><!--end .card-body -->
            </div><!--end .card -->

            <a href="{{ route('carousel.index') }}" class="col-md-6 col-md-offset-3 btn ink-reaction btn-success">Save</a>
        </div><!--end .col -->
    </div>
    @endsection
@section('scripts')
{{-- <script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.5.1/min/dropzone.min.js"></script> --}}
<script src="{{ asset('assets/backend/js/libs/dropzone/dropzone.min.js') }}"></script>
<script type="text/javascript">
    Dropzone.options.addPhotosForm = {
        paramName: 'photo',
        maxFileSize: 20,
        acceptedFiles: '.jpg, .jpeg',
        dictDefaultMessage: "Drop images here to upload",
    };
</script>
@stop