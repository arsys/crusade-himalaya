@extends('layouts.frontend')
@section('content')
<section class="uk-container-expand about" uk-grid>

</section>
<div class="uk-container uk-margin-medium-top uk-margin-medium-bottom">
	<div class=" uk-grid-match uk-grid-small uk-text-center" uk-grid>
	    <div class="uk-width-1-3@s uk-text-center">
	    	<a href="/packages"><div class="uk-height-medium uk-flex uk-flex-center uk-flex-middle uk-background-cover uk-light" data-src="https://source.unsplash.com/320x480/?trekking" uk-img>
				  	<a href="/packages"><h1 class="uk-text-center">Trekking</h1></a>
				</div>
			</a>
	    </div>
	    <div class="uk-width-1-3@s">
          	<a href="/packages"><div class="uk-height-medium uk-flex uk-flex-center uk-flex-middle uk-background-cover uk-light" data-src="https://source.unsplash.com/320x480/?trekking" uk-img>
				  	<a href="/packages"><h1 class="uk-text-center">Trekking</h1></a>
				</div>
			</a>
	    </div>
        <div class="uk-width-1-3@s">
          	<a href="/packages"><div class="uk-height-medium uk-flex uk-flex-center uk-flex-middle uk-background-cover uk-light" data-src="https://source.unsplash.com/320x480/?trekking" uk-img>
				  	<a href="/packages"><h1 class="uk-text-center">Trekking</h1></a>
				</div>
			</a>
	    </div>

	</div>
</div>
@stop