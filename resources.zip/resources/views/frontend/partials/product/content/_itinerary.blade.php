<div class="uk-panel uk-padding-large uk-padding-remove-horizontal uk-padding-remove-top">				
	<ul class="uk-list uk-list-divider" uk-accordion="multiple: true">
		<li class="uk-open">
			<a class="uk-accordion-title" href="#">Item 1</a>
			<div class="uk-accordion-content">
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
			</div>
		</li>
		<li>
			<a class="uk-accordion-title" href="#">Item 2</a>
			<div class="uk-accordion-content">
				<p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor reprehenderit.</p>
			</div>
		</li>
		<li>
			<a class="uk-accordion-title" href="#">Item 3</a>
			<div class="uk-accordion-content">
				<p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat proident.</p>
			</div>
		</li>
	</ul>
</div>