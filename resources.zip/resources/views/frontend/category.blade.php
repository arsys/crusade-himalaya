@extends('layouts.frontend')
@section('content')
<!-- image start -->
@include ('frontend.partials.category._image')
<!-- image end -->
<!-- package start -->
@include ('frontend.partials.category._package')
<!-- package end -->

@stop